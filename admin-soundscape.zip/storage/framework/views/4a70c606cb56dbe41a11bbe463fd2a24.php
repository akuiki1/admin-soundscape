

<?php $__env->startSection('content'); ?>
    <div>
        <div class="row">
            <div class="col-12">
                <div class="card mb-4 mx-4">
                    <div class="card-header pb-0">
                        <div class="d-flex flex-row justify-content-between">
                            <div>
                                <h5 class="mb-0">Kelola Tiket</h5>
                            </div>
                            <a href="<?php echo e(route('tickets.create')); ?>" class="btn bg-gradient-primary btn-sm mb-0" type="button">+&nbsp; Tiket Baru</a>
                        </div>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">ID</th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Nama</th>
                                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Tanggal</th>
                                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Harga</th>
                                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Tersedia</th>
                                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="ps-4"><?php echo e($ticket->id); ?></td>
                                            <td><?php echo e($ticket->nama); ?></td>
                                            <td class="text-center"><?php echo e($ticket->expiry_date); ?></td>
                                            <td class="text-center"><?php echo e($ticket->price); ?></td>
                                            <td class="text-center"><?php echo e($ticket->quantity); ?></td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route('tickets.edit', $ticket->id)); ?>" class="mx-3" data-bs-toggle="tooltip" data-bs-original-title="Edit ticket">
                                                    <i class="fas fa-pencil-alt text-secondary"></i>
                                                </a>
                                                <form action="<?php echo e(route('tickets.destroy', $ticket->id)); ?>" method="POST" style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" style="border:none; background:none;" data-bs-toggle="tooltip" data-bs-original-title="Hapus ticket">
                                                        <i class="cursor-pointer fas fa-trash text-secondary"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-soundscape\resources\views/ticket/tiket.blade.php ENDPATH**/ ?>