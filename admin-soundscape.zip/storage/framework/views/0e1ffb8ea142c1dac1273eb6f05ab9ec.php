  
<?php /**PATH C:\xampp\htdocs\admin-soundscape\resources\views/layouts/footers/guest/footer.blade.php ENDPATH**/ ?>