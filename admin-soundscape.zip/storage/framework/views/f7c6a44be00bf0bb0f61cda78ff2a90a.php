<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('/images/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/images/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/images/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('/images/site.webmanifest')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="//unpkg.com/alpinejs" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/css/styles.css">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        laravel: "#f56f16",
                    },
                },
            },
        };
    </script>
    <title>SoundScape | Temukan pertunjukan musik</title>
</head>

<body class="mb-48">
    <nav class="flex justify-between items-center">
        <a href="index-user"><img class="img-thumbnail;" style="padding: 30px;" src="../assets/img/SoundScape.png" alt="SoundScape logo"
            class="logo" /></a>
        <ul class="flex space-x-6 mr-6 text-lg">
            <?php if(auth()->guard()->check()): ?>
                <li>
                    <span class="font-bold uppercase">
                        Hello, <?php echo e(auth()->user()->name); ?>

                    </span>
                </li>
                <li>
                    <a href="<?php echo e(route('signup-user')); ?>" class="hover:text-laravel text-decoration-none"><i class="fa-solid fa-user"></i> Profile</a>
                </li>
                <li>
                    <form method="POST" class="inline" action="logout-user">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="hover:text-laravel"><i class="fa-solid fa-sign-out hover:text-laravel"></i> Logout</button>
                    </form>
                </li>
            <?php else: ?>
                <li>
                    <a href="<?php echo e(route('signup-user')); ?>" class="hover:text-laravel"><i class="fa-solid fa-user-plus"></i> Signup</a>
                </li>
                <li>
                    <a href="<?php echo e(route('login')); ?>" class="hover:text-laravel"><i class="fa-solid fa-arrow-right-to-bracket"></i>
                        Login</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>

    <main>

        <?php echo $__env->yieldContent('content'); ?>

    </main>

    <footer
        

    </footer>

    <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\admin-soundscape\resources\views/components/layout.blade.php ENDPATH**/ ?>