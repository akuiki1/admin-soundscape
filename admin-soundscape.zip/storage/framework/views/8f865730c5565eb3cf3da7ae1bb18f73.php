
<?php /**PATH C:\xampp\htdocs\admin-soundscape\resources\views/layouts/footers/auth/footer.blade.php ENDPATH**/ ?>