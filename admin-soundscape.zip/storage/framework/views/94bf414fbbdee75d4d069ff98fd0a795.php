<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row mb-4">
            <div class="card">
                <div class="card-header p-3">
                    <div class="row">
                        <div class="col-6 d-flex align-items-center">
                            <h6 class="mb-0">Metode Pembayaran</h6>
                        </div>
                        <div class="col-6 text-end">
                            <a class="btn bg-gradient-primary mb-0" href="<?php echo e(route('billings.create')); ?>"><i
                                    class="fas fa-plus"></i>&nbsp;&nbsp;Metode Pembayaran Baru</a>
                        </div>
                    </div>
                </div>
                <div class="card-body p-3">
                    <div class="row">
                        <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 mb-md-0 mb-4">
                                <div
                                    class="card card-body border card-plain border-radius-lg flex align-items-center flex-row">
                                    <img class="w-20 h-20 me-3 mb-0" src="<?php echo e(asset($method->bank_logo)); ?>" alt="logo">
                                    <div class="row">
                                        <p class="text-s font-weight-bold mb-0"><?php echo e($method->account_name); ?></p>
                                        <p class="text-xs text-secondary mb-0"><?php echo e($method->account_number); ?></p>
                                    </div>
                                    <div class="d-flex justify-space-between mb-0">
                                        <a class="fas fa-pencil-alt ms-auto text-dark cursor-pointer me-3 p-1"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Edit Card"
                                            href="<?php echo e(route('billings.edit', $method->id)); ?>"></a>
                                        <form action="<?php echo e(route('billings.destroy', $method->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button
                                                class="fas fa-trash-alt ms-auto text-dark cursor-pointer border-0 bg-transparent"
                                                data-bs-toggle="tooltip" data-bs-placement="top"
                                                title="Delete Card"></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-4">
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0">Daftar Transaksi</h6>
                </div>
                <div class="table-responsive p-0">
                    <table class="table align-items-center justify-center mb-0">
                        <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    ID
                                </th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                    Nama User
                                </th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Nama Event
                                </th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Jumlah Pembelian Tiket
                                </th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Total Harga
                                </th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Status Pembayaran
                                </th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Tanggal Pembayaran
                                </th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Bukti Transfer
                                </th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    Tindakan
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="ps-4">
                                        <p class="text-xs font-weight-bold mb-0"><?php echo e($transaction->id); ?></p>
                                    </td>
                                    <td class="text">
                                        <?php if($transaction->user): ?>
                                            <p class="text-xs font-weight-bold mb-0"><?php echo e($transaction->user->name); ?></p>
                                        <?php else: ?>
                                            <p class="text-xs font-weight-bold mb-0">Pengguna Tidak Ditemukan</p>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($transaction->event): ?>
                                            <p class="text-xs font-weight-bold mb-0"><?php echo e($transaction->event->name); ?></p>
                                        <?php else: ?>
                                            <p class="text-xs font-weight-bold mb-0">Event Tidak Ditemukan</p>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($transaction->quantity): ?>
                                            <p class="text-xs font-weight-bold mb-0"><?php echo e($transaction->quantity); ?></p>
                                        <?php else: ?>
                                            <p class="text-xs font-weight-bold mb-0">Jumlah Tiket Tidak ditemukan</p>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($transaction->total_price): ?>
                                            <p class="text-xs font-weight-bold mb-0">
                                                <?php echo e('Rp ' . number_format($transaction->total_price, 0, ',', '.')); ?></p>
                                        <?php else: ?>
                                            <p class="text-xs font-weight-bold mb-0">Total Harga Tidak Ditemukan</p>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($transaction->status == 'pending'): ?>
                                            <p class="badge badge-sm bg-gradient-warning">
                                                <?php echo e(ucfirst($transaction->status)); ?></p>
                                        <?php elseif($transaction->status == 'confirmed'): ?>
                                            <p class="badge badge-sm bg-gradient-success">
                                                <?php echo e(ucfirst($transaction->status)); ?></p>
                                        <?php elseif($transaction->status == 'rejected'): ?>
                                            <p class="badge badge-sm bg-gradient-danger">
                                                <?php echo e(ucfirst($transaction->status)); ?></p>
                                            
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <p class="text-xs font-weight-bold mb-0"><?php echo e($transaction->payment_date); ?></p>
                                    </td>
                                    <td class="text-center">
                                        <?php if($transaction->bukti_transaksi): ?>
                                            <a href="<?php echo e(asset('storage/' . $transaction->bukti_transaksi)); ?>"
                                                target="_blank" class="badge badge-sm bg-gradient-info">Lihat Bukti</a>
                                        <?php else: ?>
                                            <p class="text-xs font-weight-bold mb-0">Tidak Ada</p>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($transaction->status == 'pending'): ?>
                                            <form action="<?php echo e(route('transactions.confirm', $transaction->id)); ?>"
                                                method="POST" style="display:inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="badge badge-sm bg-gradient-success border-0">Konfirmasi</button>
                                            </form>
                                            <form action="<?php echo e(route('transactions.reject', $transaction->id)); ?>"
                                                method="POST" style="display:inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="badge badge-sm bg-gradient-danger border-0">Tolak</button>
                                            </form>
                                        <?php elseif($transaction->status == 'confirmed'): ?>
                                            <a href="<?php echo e(route('transactions.print', $transaction->id)); ?>" class="btn bg-gradient-primary">Cetak Tiket</a>
                                        <?php else: ?>
                                            <form action="<?php echo e(route('hapus-transaksi', $transaction->id)); ?>" method="POST"
                                                style="display:inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                    class="btn bg-gradient-danger border-0">Hapus</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-soundscape\resources\views/transaksi/billing.blade.php ENDPATH**/ ?>