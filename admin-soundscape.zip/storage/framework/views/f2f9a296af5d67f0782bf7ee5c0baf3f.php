

<?php $__env->startSection('content'); ?>
    <div>
        <div class="row">
            <div class="col-12">
                <div class="card mb-4 mx-4">
                    <div class="card-header pb-0">
                        <div class="d-flex flex-row justify-content-between">
                            <div class="d-flex flex-row justify-content-between mr-4">
                                <a href="<?php echo e(route('events.index')); ?>" class="mb-0 mr-4">
                                    <i class="fas fa-arrow-left"></i>
                                </a>
                                <div>
                                    <h5 class="mb-4" style="margin-left: 15px">Edit Event</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="p-3">
                            <form action="<?php echo e(route('events.update', $event->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="mb-3">
                                    <label for="photo" class="form-label">Foto</label>
                                    <input type="file" class="form-control" id="photo" name="photo">
                                </div>
                                <div class="mb-3">
                                    <label for="name" class="form-label">Nama</label>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e($event->name); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="id_venue" class="form-label">Venue</label>
                                    <select name="id_venue" id="id_venue" class="form-control">
                                        <option value="">Pilih Venue</option>
                                        <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($venue->id_venue); ?>" <?php echo e($venue->id_venue == $event->id_venue ? 'selected' : ''); ?>><?php echo e($venue->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="id_ticket" class="form-label">Tiket</label>
                                    <select name="id_ticket" id="id_ticket" class="form-control">
                                        <option value="">Pilih Tiket</option>
                                        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($ticket->id); ?>" <?php echo e($ticket->id == $event->id_ticket ? 'selected' : ''); ?>><?php echo e($ticket->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="date" class="form-label">Tanggal Pelaksanaan</label>
                                    <input type="datetime-local" class="form-control" id="date" name="date" value="<?php echo e($event->date->format('Y-m-d\TH:i')); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select name="status" id="status" class="form-control">
                                        <option value="segera" <?php echo e($event->status == 'segera' ? 'selected' : ''); ?>>Segera</option>
                                        <option value="aktif" <?php echo e($event->status == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                                        <option value="berlangsung" <?php echo e($event->status == 'berlangsung' ? 'selected' : ''); ?>>Berlangsung</option>
                                        <option value="berakhir" <?php echo e($event->status == 'berakhir' ? 'selected' : ''); ?>>Berakhir</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="description" class="form-label">Deskripsi</label>
                                    <textarea class="form-control" id="description" name="description"><?php echo e($event->description); ?></textarea>
                                </div>
                                <button type="submit" class="btn bg-gradient-primary btn-md mt-4 mb-4">Simpan Perubahan</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-soundscape\resources\views/event/edit-event.blade.php ENDPATH**/ ?>