

<?php $__env->startSection('content'); ?>
    <div>
        <div class="row">
            <div class="col-12">
                <div class="card mb-4 mx-4">
                    <div class="card-header pb-0">
                        <div class="d-flex flex-row justify-content-between">
                            <div class="d-flex flex-row justify-content-between mr-4">
                                <a href="<?php echo e(url('users')); ?>" class="mb-0 mr-4">
                                    <i class="fas fa-arrow-left"></i>
                                </a>
                                <div>
                                    <h5 class="mb-4" style="margin-left: 15px">Edit User</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="p-3">
                            <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                            
                                <div class="mb-3">
                                    <label for="foto" class="form-label">Foto</label>
                                    <input type="file" class="form-control" id="foto" name="foto" value="<?php echo e($user->foto); ?>"> 
                                </div>
                            
                                <div class="mb-3">
                                    <label for="nama" class="form-label">Nama</label>
                                    <input type="text" class="form-control" id="nama" name="name" value="<?php echo e($user->name); ?>" required>
                                </div>
                            
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>
                                </div>
                            
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" class="form-control" placeholder="Password" name="password" id="password" aria-label="Password" aria-describedby="password-addon">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <p class="text-danger text-xs mt-2"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Telepon</label>
                                    <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($user->phone); ?>">
                                </div>
                            
                                <div class="mb-3">
                                    <label for="location" class="form-label">Alamat</label>
                                    <input type="text" class="form-control" id="location" name="location" value="<?php echo e($user->location); ?>"> 
                                </div>
                            
                                <div class="mb-3">
                                    <label for="about_me" class="form-label">Tentang Saya</label>
                                    <textarea class="form-control" id="about_me" name="about_me" rows="3"><?php echo e($user->about_me); ?></textarea>
                                </div>
                            
                                <div class="mb-3">
                                    <label for="role" class="form-label">Role</label>
                                    <select name="role" id="role" class="form-control">
                                        <option value="">Pilih Role</option>
                                        <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Admin</option>
                                        <option value="user" <?php echo e($user->role == 'user' ? 'selected' : ''); ?>>User</option>
                                    </select>
                                </div>
                            
                                <div class="d-flex justify-content-end">
                                    <a href="<?php echo e(url('users')); ?>" class="btn btn-gradient-dark btn-sm mb-8 me-2">Batal</a>
                                    <button type="submit" class="btn bg-gradient-primary btn-sm mb-8">Simpan</button>
                                </div>
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-soundscape\resources\views/users/edit.blade.php ENDPATH**/ ?>