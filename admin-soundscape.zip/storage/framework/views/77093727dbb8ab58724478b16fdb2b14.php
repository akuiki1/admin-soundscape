<?php if(session()->has('message')): ?>
    <div x-data="{ show: true }" 
        x-init="setTimeout(() => show = false, 3000)" 
        x-transition:leave="transition ease-in duration-300" 
        x-transition:leave-start="opacity-100 scale-100"
        x-transition:leave-end="opacity-0 scale-90" 
        x-show="show"
        class="fixed top-5 left-1/2 transform -translate-x-1/2 bg-laravel text-white px-20 py-3 rounded-lg">
        <p><?php echo e(session('message')); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\admin-soundscape\resources\views/components/flash-message.blade.php ENDPATH**/ ?>