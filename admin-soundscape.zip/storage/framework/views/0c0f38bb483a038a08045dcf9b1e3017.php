<?php $__env->startSection('content'); ?>
    <div class="px-4 md:px-0">
        <div class="mx-4 max-w-4xl mx-auto mt-24">
            <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => '!p-10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '!p-10']); ?>
                <a href="<?php echo e(route('index-user')); ?>" class="inline-block text-black ml-4 mb-4">
                    <i class="fa-solid fa-arrow-left"></i> Back
                </a>
                <div class="flex flex-col items-center text-center">
                    <img class="hidden w-50 md:block"
                        src="<?php echo e($event->photo ? asset($event->photo) : asset('/images/no-image.png')); ?>"
                        alt="Event Photo" class="w-48 h-100 mb-4" />
                    <h1 class="text-3xl mb-2"><?php echo e($event->name); ?></h1>
                    <div class="text-sm my-2">
                        <i class="fa-solid fa-calendar-alt mr-2"></i> <?php echo e($event->date->format('d F Y')); ?> <br>
                        <i class="fa-solid fa-location-dot mr-2"></i> <?php echo e($event->venue->address); ?>

                    </div>
                    <div class="border-t border-gray-200 w-full mb-6"></div>
                    <div class="w-full">
                        <h3 class="text-3xl font-bold mb-4">Deskripsi Event</h3>
                        <p class="text-lg space-y-6 pb-10"><?php echo e($event->description); ?></p>
                    </div>
                    <h3 class="text-3xl font-bold mb-4">Layout Venue</h3>
                    <div class="flex items-center justify-center mb-6">
                        <img src="<?php echo e($event->venue->photo ? asset($event->venue->photo) : asset('/images/no-image.png')); ?>" alt="Venue Photo" class="w-50 h-100">
                    </div>
                    <div class="w-full flex justify-between items-center mt-8">
                        <div class="flex flex-col items-start">
                            <h3 class="text-3xl font-bold mb-4">Harga Tiket</h3>
                            <p class="text-lg text-orange-500 mb-6">IDR <?php echo e(number_format($event->ticket->price, 0, ',', '.')); ?> / Tiket</p>
                        </div>
                        <a href="<?php echo e(url('buy-ticket', ['event_id' => $event->id])); ?>" class="bg-orange-500 text-white py-2 px-4 rounded-xl hover:bg-orange-600 transition duration-300">Beli Tiket</a>
                    </div>                    
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-soundscape\resources\views/tampilanuser/event/index.blade.php ENDPATH**/ ?>