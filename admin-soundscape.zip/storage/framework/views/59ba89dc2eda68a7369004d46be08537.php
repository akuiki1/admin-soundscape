

<?php $__env->startSection('content'); ?>
<div class="px-4 md:px-0">
    <div class="mx-4 max-w-4xl mx-auto mt-24">
        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => '!p-10 bg-white shadow-md rounded-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '!p-10 bg-white shadow-md rounded-lg']); ?>
            <a href="<?php echo e(route('index-user')); ?>" class="inline-block text-gray-700 ml-4 mb-4 hover:text-gray-900">
                <i class="fa-solid fa-arrow-left"></i> Kembali Ke Beranda
            </a>
            <div class="flex flex-col items-center justify-center text-center">
                <h1 class="text-4xl font-bold text-green-600 mb-4">Pembelian Tiket <?php echo e($event->name); ?> Berhasil</h1>
                <div class="bg-green-100 p-6 rounded-lg shadow-inner">
                    <p class="text-lg text-gray-800">
                        Terima kasih telah melakukan pembelian tiket untuk acara <strong><?php echo e($event->name); ?></strong>. ID Transaksi Anda adalah <strong><?php echo e($transaction->id); ?></strong>.
                    </p>
                    <p class="mt-4 text-sm text-gray-600">
                        Jika Anda memiliki pertanyaan atau membutuhkan bantuan lebih lanjut, silakan hubungi admin kami dengan mengklik tombol di bawah ini.
                    </p>
                    <a href="https://wa.me/6281254418925?text=Saya%20telah%20melakukan%20pembayaran%20untuk%20event%20<?php echo e($event->name); ?>%20dengan%20ID%20Transaksi:%20<?php echo e($transaction->id); ?>" class="mt-6 inline-block bg-green-500 text-white py-2 px-4 rounded-lg shadow hover:bg-green-600 transition duration-300">
                        Hubungi Admin
                    </a>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin-soundscape\resources\views/tampilanuser/event/complete.blade.php ENDPATH**/ ?>